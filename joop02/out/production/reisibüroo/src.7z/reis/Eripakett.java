package reis;

/**
 * Created by Ain-Joonas on 20.03.2015.
 */
public class Eripakett extends Reis {
    double people = 0;
    public Eripakett(String name, double length, double maxPeople, double price) {
        super(name, length, maxPeople, price);

        if(people >= maxPeople) this.people = maxPeople;
        if(maxPeople >= 15) price = 150;

    }

    protected double addPeople(double people){
        this.people = people;
        return people;
    }
    protected double pricePerPerson(double people){
        if(people >= maxPeople) return -1;
        double pricePerPerson = price / people;
        return pricePerPerson;
    }

    @Override
    public String toString() {
        return "Eripakett{" +
                "rahvaarv=" + people +
                '}' + "erireis";
    }
}
