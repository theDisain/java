package reisibyroo;

import reis.Eripakett;
import reis.Reis;

import java.util.ArrayList;

/**
 * Created by Ain-Joonas on 20.03.2015.
 */
public class Reisibyroo {
    private static ArrayList<Reis> reisid = new ArrayList<>();
    public Reisibyroo(){}
    public Reis uusReis(String name, double length, double maxPeople, double price){
        Reis reis = new Reis(name, length,maxPeople,price);
        reisid.add(reis);
        return reis;
    }
    public Reis uusEriReis(String name, double length, double maxPeople, double price){
        Reis erareis = new Eripakett(name, length,maxPeople,price);
        reisid.add(erareis);
        return erareis;
    }

}
