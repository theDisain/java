package Kontor;

import reis.Eripakett;
import reis.Reis;
import reisibyroo.Reisibyroo;


/**
 * Created by Ain-Joonas on 20.03.2015.
 */
public class reisiTest {
    public static void main(String[] args) {
        Reisibyroo s = new Reisibyroo();
        System.out.println("sõna");
        Reis suusareis = s.uusReis("reis", 2,3,4);
        System.out.println(suusareis.toString());
        Eripakett itaalia = (Eripakett) s.uusEriReis("Itaalia", 24,2,5);
        System.out.println(itaalia.number());

    }
}
