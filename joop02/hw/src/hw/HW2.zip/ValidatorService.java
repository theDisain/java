package hw;

/**
 * Created by Ain-Joonas on 19.02.2015.
 */
public interface ValidatorService {
    public boolean validate(int id);

    public boolean isValidated(int id);
}
